"""Real DB integration tests. TEST_DATABASE_URL must point to a disposable database."""
import os
import uuid
import asyncio
from pathlib import Path
from types import SimpleNamespace
import asyncpg
import pytest
import pytest_asyncio
from bot.db import Store

pytestmark=pytest.mark.skipif(not os.getenv('TEST_DATABASE_URL'),reason='Disposable PostgreSQL not configured')

@pytest_asyncio.fixture
async def store():
    pool=await asyncpg.create_pool(os.environ['TEST_DATABASE_URL'])
    await pool.execute(Path(__file__).parents[1].joinpath('schema.sql').read_text())
    db=Store(pool)
    uid=uuid.uuid4().int % 10**12+1
    await db.user(SimpleNamespace(id=uid,username='test',full_name='Test'))
    await pool.execute("UPDATE research.services SET stars_price=100 WHERE service_id=1")
    await pool.execute("INSERT INTO research.vault_data(service_id,encrypted_payload) VALUES(1,'test-only-not-valid-ciphertext')")
    yield db,uid
    await pool.close()

@pytest.mark.asyncio
async def test_simultaneous_approvals_grant_once(store):
    db,uid=store
    tid,_,_=await db.order(uid,1,'INR','1')
    assert await db.screenshot(uid,tid,'photo')
    result=await asyncio.gather(db.review(tid,True,9),db.review(tid,True,9))
    assert sum(r is not None for r in result)==1
    assert await db.allowed(uid,1)
    assert await db.pool.fetchval('SELECT count(*) FROM research.delivery_jobs WHERE txn_id=$1',tid)==1

@pytest.mark.asyncio
async def test_wrong_amount_owner_and_replayed_receipt(store):
    db,uid=store
    tid,_,_=await db.order(uid,1,'XTR','1')
    assert not await db.precheckout(uid,tid,'XTR',99)
    assert not await db.precheckout(uid+1,tid,'XTR',100)
    with pytest.raises(ValueError):
        await db.paid(uid,tid,'XTR',99,'charge-'+str(tid))
    assert await db.paid(uid,tid,'XTR',100,'charge-'+str(tid))
    assert not await db.paid(uid,tid,'XTR',100,'charge-'+str(tid))
    assert await db.pool.fetchval('SELECT count(*) FROM research.delivery_jobs WHERE txn_id=$1',tid)==1

@pytest.mark.asyncio
async def test_banned_revoked_expired_denied(store):
    db,uid=store
    tid,_,_=await db.order(uid,1,'XTR','1')
    await db.paid(uid,tid,'XTR',100,'charge-'+str(tid))
    await db.pool.execute('UPDATE research.users SET is_banned=true WHERE user_id=$1',uid)
    assert not await db.allowed(uid,1)
    await db.pool.execute('UPDATE research.users SET is_banned=false WHERE user_id=$1',uid)
    await db.pool.execute('UPDATE research.entitlements SET revoked=true WHERE user_id=$1',uid)
    assert not await db.allowed(uid,1)
    await db.pool.execute("UPDATE research.entitlements SET revoked=false,expires_at=now()-interval '1 second' WHERE user_id=$1",uid)
    assert not await db.allowed(uid,1)

@pytest.mark.asyncio
async def test_cancel_and_duplicate_screenshot(store):
    db,uid=store
    tid,_,_=await db.order(uid,1,'INR','1')
    await db.cancel(uid)
    assert not await db.screenshot(uid,tid,'photo')
    tid,_,_=await db.order(uid,1,'INR','1')
    assert await db.screenshot(uid,tid,'photo')
    assert not await db.screenshot(uid,tid,'photo2')
