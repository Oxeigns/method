"""Entrypoint: python main.py. Secrets and research never enter application logs."""
import asyncio
import logging
import signal
import asyncpg
from aiogram import Bot,Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.fsm.storage.redis import RedisStorage,RedisEventIsolation
from aiogram.types import ErrorEvent
from redis.asyncio import Redis
from bot.config import Config
from bot.crypto import VaultCipher
from bot.db import Store
from bot.middleware import Guard
from bot import admin,user
from bot.workers import delivery_loop,deletion_loop,notify_loop,broadcast_loop,receipt_loop
from bot.polling import poll

async def main():
    cfg=Config.load()
    cipher=VaultCipher(cfg.keys)
    pool=await asyncpg.create_pool(cfg.database_url,ssl=cfg.database_ssl,min_size=2,max_size=8,command_timeout=15)
    # Keep a dedicated connection for the entire process; session pooler or direct DB only.
    lock=await asyncpg.connect(cfg.database_url,ssl=cfg.database_ssl)
    if not await lock.fetchval('SELECT pg_try_advisory_lock(73190481923)'):
        await lock.close()
        await pool.close()
        raise RuntimeError('Another bot instance holds the singleton lock.')
    redis=Redis.from_url(cfg.redis_url)
    await redis.ping()
    storage=RedisStorage(redis,state_ttl=3600,data_ttl=3600)
    dp=Dispatcher(storage=storage,events_isolation=RedisEventIsolation(redis,lock_kwargs={'timeout':120}))
    bot=Bot(cfg.token,default=DefaultBotProperties(parse_mode='HTML',protect_content=True))
    store=Store(pool)
    guard=Guard(store,cfg,redis)
    for observer in (dp.message,dp.callback_query,dp.pre_checkout_query):
        observer.outer_middleware(guard)
    dp.include_routers(admin.confirm_router,user.router,admin.router)

    @dp.errors()
    async def error(event: ErrorEvent):
        # Avoid exception strings/traces: upstream errors can include message content.
        logging.error('Update failed type=%s update_id=%s',type(event.exception).__name__,event.update.update_id)
        try:
            if event.update.callback_query:
                await event.update.callback_query.answer('Action failed. Retry or contact /support.',show_alert=True)
            elif event.update.message:
                await event.update.message.answer('Action failed. Retry or contact /support. Existing payments remain recorded.')
        except Exception:
            pass
        return True

    async def supervise_lock():
        # Stop processing if singleton connection is lost; never run an unlocked worker.
        while True:
            await lock.fetchval('SELECT 1')
            await asyncio.sleep(10)

    stop=asyncio.Event()
    asyncio.get_running_loop().add_signal_handler(signal.SIGTERM,stop.set)
    tasks=[]
    try:
        # Preserve pending receipts; never use drop_pending_updates=True.
        await bot.delete_webhook(drop_pending_updates=False)
        tasks=[asyncio.create_task(fn) for fn in (
            delivery_loop(bot,store,cipher), deletion_loop(bot,store),
            notify_loop(bot,store,cfg),broadcast_loop(bot,store,cipher),supervise_lock(),
            receipt_loop(bot,store,cfg),poll(bot,dp,store,cfg,cipher),stop.wait())]
        done,_=await asyncio.wait(tasks,return_when=asyncio.FIRST_COMPLETED)
        for task in done:
            task.result()
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks,return_exceptions=True)
        await storage.close()
        await bot.session.close()
        await lock.close()
        await pool.close()

if __name__=='__main__':
    logging.basicConfig(level=logging.WARNING,format='%(asctime)s %(levelname)s %(name)s %(message)s')
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
