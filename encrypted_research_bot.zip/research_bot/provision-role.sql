-- Run AFTER schema.sql, as the migration owner. Create research_app yourself with
-- a strong password via your DB console. This script never embeds credentials.
GRANT USAGE ON SCHEMA research TO research_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA research TO research_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA research TO research_app;
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['users','services','transactions','vault_data','admin_settings','entitlements','delivery_jobs','deletion_jobs','audit_log','broadcasts','payment_receipts'] LOOP
 EXECUTE format('DROP POLICY IF EXISTS bot_access ON research.%I',t);
 EXECUTE format('CREATE POLICY bot_access ON research.%I TO research_app USING (true) WITH CHECK (true)',t);
 END LOOP;
END $$;
-- Do not expose the research schema through Supabase Data API.
