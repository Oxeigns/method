# Encrypted Research Telegram Bot

Modular Python 3.12 / aiogram 3 / PostgreSQL / Redis implementation of the supplied specification. Includes full source, schema, Docker development setup, unit tests and opt-in PostgreSQL integration tests. No proprietary research or credentials are bundled.

**Status:** implemented and locally unit-tested; not deployed or certified production-ready. Run the database integration suite and Telegram test-environment acceptance checks below before accepting money.

## Payment design: a necessary specification correction

Telegram requires **Telegram Stars (XTR)** for digital goods/services sold inside Telegram apps. This bot therefore defaults to Stars. The supplied INR prices are retained exactly in the database, while Stars prices start unset. There is no invented INR-to-Stars conversion; the owner must choose each Stars price.

The requested manual UPI screenshot checkout, bank verification queue, approval/rejection and dynamic UPI setting are implemented as an **optional, disabled mode**. Using UPI to sell this research inside Telegram conflicts with Telegram's current digital-goods payment requirements. An acknowledgement flag is a configuration safeguard, not an exemption from those rules. Keep `PAYMENT_MODE=stars` for this deployment.

Official sources:
- https://core.telegram.org/bots/payments-stars
- https://core.telegram.org/bots/api#sendmessage
- https://core.telegram.org/bots/api#deletemessage
- https://docs.aiogram.dev/en/latest/dispatcher/finite_state_machine/storages.html

## Included behavior

- `/start`, service descriptions, explicit terms agreement, checkout, `/cancel`, profile/purchase history, support, `/terms`, `/paysupport`.
- Owner-only `/adminpanel`, including callback and FSM authorization on every action.
- Encrypted, per-service research blocks with authenticated Fernet encryption. Service ID is included inside the authenticated envelope to reject swapped ciphertext.
- Protected private-chat delivery, user-ID watermark, HTML escaping and conservative Unicode-safe message splitting.
- Durable 24-hour deletion jobs (configurable down to 60 seconds per service), delivery retries and per-chunk resumption.
- PostgreSQL payment receipt inbox written before confirming the Telegram polling offset; replay-safe charge IDs and atomic entitlement/delivery grants.
- Optional UPI screenshot FSM, cancellation/expiry, owner verification, duplicate-decision protection and screenshot notifications.
- Dynamic prices, additional reporting-method services, validity periods, bans, revocation and manual extensions.
- Encrypted broadcast queue, owner preview/confirmation, rate limiting and blocked-user handling.
- Stars refunds with recoverable `Refunding` status and payment support.
- Private database schema, RLS, separate runtime-role provisioning, parameterized SQL, audit metadata and secret-free application logging.

## Defaults

| Service ID | Service | INR reference price |
|---|---|---:|
| 1 | Specific Reporting Method | ₹1,500 |
| 2 | Account Limit Removal Guide | ₹300 |
| 3 | Channel Unban Procedure/Format | ₹1,500 |
| 4 | Group Ban Procedure/Format | ₹2,000 |
| 5 | Local Laws & Compliance Frameworks | ₹15,000 |

Each service is a one-time purchase. `validity_days=0` means lifetime access while the service operates; set e.g. 30 for a 30-day entitlement. Renewals extend active finite access. Automatic recurring billing is **not** implemented because no renewal interval or recurring price was specified. A lifetime grant stays lifetime when extended. Revocation/ban affects future delivery; it cannot recall already read content.

The default reporting-method service represents one method, not every method. Use `new Name of method` in Service Settings to create additional independently priced methods (default ₹1,500).

## Quick local start with Docker Compose

1. Copy `.env.example` to `.env`.
2. Set `BOT_TOKEN`, `ADMIN_ID` (numeric personal Telegram ID), `SUPPORT_USERNAME` and `MASTER_ENCRYPTION_KEYS`.
3. Add `POSTGRES_PASSWORD=<long-random-password>` to `.env` for Compose. URL-encode reserved characters in the database URL, or use a long randomly generated alphanumeric password for this example.
4. Generate a key locally:

   ```bash
   python -m pip install -r requirements.txt
   python -m bot.crypto --generate-key
   ```

5. Start:

   ```bash
   docker compose up --build -d
   ```

Compose overrides the database/Redis URLs to its internal services and initializes `schema.sql` on a **new** database volume. It publishes no database or Redis host ports. Schema changes are not automatically applied to existing volumes; apply them as reviewed migrations. Never delete a production volume to reinitialize a schema.

**Compose is a development convenience:** its database account is the bootstrap database owner/superuser. Production must use a separate least-privilege runtime role as described below. Database TLS is disabled only on the isolated Compose network; use certificate-verified TLS for remote databases and `rediss://` for remote Redis.

## Production PostgreSQL / Supabase setup

1. Provision PostgreSQL and Redis. Use direct PostgreSQL or a **session** pooler; transaction pooling is incompatible with the singleton advisory lock. Do not expose the `research` schema via Supabase's Data API.
2. Apply `schema.sql` with a migration/owner account (SQL console or `psql`). Alternatively `python init_db.py` uses the configured database URL and requires the other mandatory environment settings to be present.
3. Create a dedicated PostgreSQL login named `research_app` with a strong secret through your database administration console, then run `provision-role.sql` with the migration owner.
4. Put that limited role's connection string in `DATABASE_URL`. This project uses PostgreSQL directly, so Supabase anon/service-role API keys are neither required nor used.
5. Set `DATABASE_SSL=require` (default). It creates a certificate-verifying SSL context with system trusted CAs. Install your provider's CA if needed; do not disable verification for a public database.
6. Set Redis credentials and TLS, isolate it from the internet, and use persistent storage. FSM stores identifiers and encrypted broadcast text; it does not store raw vault content.
7. Set the environment secrets; never commit `.env`. Store encryption keys separately from database backups. Losing all keys permanently loses research content.
8. Install requirements and run `python main.py` under a process supervisor, or use the Dockerfile with your managed database/Redis configuration. Run **one replica**. The process holds a session advisory lock and stops if that connection is lost. SIGTERM cancels workers and closes connections.

## Owner setup in Telegram

The owner must first open the bot and press Start so the bot can send payment notifications.

1. `/adminpanel` → Payment / Support: set `support_username @YourSupport` and publish real purchase/refund terms using `terms Your text here`.
2. Service Settings: send, for example, `1 stars_price 100`. This is only an example, not a recommended conversion from INR.
3. If desired, set `1 validity_days 30`. Set `1 delete_after_seconds 86400` for 24-hour deletion. These settings apply to new purchases; purchase validity is snapshotted on the transaction.
4. Vault Management: choose service ID `1`, then send a research block. Repeat for additional blocks. The bot encrypts it before database insertion and attempts to delete the owner's incoming message.
5. Repeat for the other services. Empty vaults and missing Stars prices cannot be purchased.

Service settings also support `price`, `is_active`, `description`, and `service_name`. `is_active false` stops both purchase and delivery, including existing entitlements; use this intentionally. The interface supports appending vault blocks. To replace/delete blocks, use reviewed database maintenance with freshly encrypted payloads; never write plaintext into `vault_data`.

User Management commands:

```text
ban USER_ID
unban USER_ID
revoke USER_ID SERVICE_ID
extend USER_ID SERVICE_ID DAYS
```

Only users who have started the bot can be managed. `DAYS=0` grants lifetime access. Banning does not automatically refund purchases. Previously queued deliveries marked blocked can be requested again after access is restored.

Broadcasts require an owner preview and Send confirmation. Broadcast content is escaped plain text inside a formatted announcement, not arbitrary executable HTML. Emoji-rich inline buttons are used; Telegram clients control button styling/colors.

## Optional manual UPI implementation

This section documents the requested implementation, not permission to deploy it for digital-goods sales.

```text
PAYMENT_MODE=upi
ACKNOWLEDGE_UPI_PLATFORM_RESTRICTION=true
```

Set `upi_id name@bank` in Payment / Support. Checkout snapshots amount/validity, displays a copyable UPI ID, and waits for a **photo** screenshot for 30 minutes. Redis FSM expires after an hour. `/cancel`, `/start` and returning to the catalog clear abandoned input state. Submitted screenshot transactions stay pending until owner review.

The notification worker sends the screenshot to the owner using its Telegram file ID; this is a new protected message, not a forward. Owners must check actual bank settlement, amount, payer/reference and duplicate bank references before approval; a screenshot alone does not prove payment. No automatic bank/UTR verification exists. Approval grants access and queues content in one database transaction. Rejection shows Payment Invalid and support. The verification queue shows ten entries at a time; resolve and reopen to see the next batch.

## Encryption and privacy boundaries

Fernet provides AES-128-CBC encryption with HMAC authentication and random IVs. The IV is embedded in the token; the requested `encryption_iv` column is deliberately NULL, avoiding a redundant or reused IV. Metadata (user IDs, service names, prices, transaction status) is not encrypted; research and queued broadcast bodies are.

`MASTER_ENCRYPTION_KEYS` is a comma-separated MultiFernet key ring. The first encrypts new blocks; remaining keys decrypt older blocks. To rotate: back up ciphertext and keys separately, prepend a new key, restart, and retain old keys until every historical ciphertext and needed backup has been re-encrypted. No automatic mass-rotation command is included.

Plaintext is decrypted only in memory for a currently authorized recipient. Python does not guarantee secure memory wiping. Disable payload tracing, crash/core dumps and debug HTTP logging on the host. Host compromise or theft of both the database and encryption keys can expose content.

Telegram bot chats are **not end-to-end encrypted**. Transport is HTTPS to Telegram, then handled by Telegram's infrastructure. Research typed into the owner chat has already passed through Telegram even if the bot subsequently deletes the message. Do not use this system for material whose threat model excludes Telegram itself.

`protect_content=True` is explicit on every research delivery and is also the Bot default. It reduces forwarding/saving through supported clients; it cannot prevent external cameras, manual transcription or every capture technique. No absolute anti-piracy guarantee is possible.

Deletion is scheduled for 24 hours, subject to worker availability and Telegram API rules (ordinary deletion generally has a 48-hour limit). Monitor overdue deletions. A lengthy outage may make old messages undeletable. There is an unavoidable small non-atomic window between Telegram accepting a send and the database storing its message ID: a crash/network ambiguity in that window can produce a duplicate and/or an untracked message. Telegram sendMessage offers no cross-system transaction; this implementation cannot promise exactly-once delivery or absolute timed erasure.

## Operations and recovery

- Preserve pending Telegram updates; the application never drops them on startup. Telegram retains updates for a limited time, so avoid prolonged outages and reconcile payments against Telegram Stars transaction history.
- `payment_receipts`: `pending` retries automatically; `reconcile` needs manual inspection of the charge, payer, invoice and amount. No access is granted for mismatched payments. Alert on this table even if the owner notification cannot be delivered.
- `transactions.status='Refunding'`: retry the same transaction UUID from Stars Refund. An already-refunded charge is treated as success. Refund access revocation occurs before the API call; if refund fails, access stays revoked until the owner resolves it.
- Refund currently revokes **all** access to that service for the payer, even if they have other purchases. The UI warns about this. Restore remaining valid access manually if appropriate. Refunded/reversed payments initiated outside this bot require reconciliation; there is no automated chargeback-history synchronizer.
- `delivery_jobs`: inspect pending attempts and blocked status. Invalid ciphertext retries with capped backoff; fix the key/content instead of replacing data with plaintext.
- `deletion_jobs`: alert on repeatedly failing attempts. Telegram-forbidden or permanently expired deletions remain visible, rather than being silently marked successful.
- `broadcasts`: cursor resumes across restarts; sends are at-least-once around a crash. Delete old completed encrypted broadcasts according to your retention policy.
- Back up PostgreSQL, protect Redis, retain audit trails, and test restore procedures. Restrict administrative access and enable Telegram two-step verification for the owner account.

## Tests and release gate

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

Unit tests cover encryption/tampering/key rotation, service binding, owner callback/FSM isolation, private-chat enforcement, bans, access checks before decryption, HTML/Unicode splitting, protected delivery, deletion scheduling, chunk resumption, payment mismatches, duplicate receipts and receipt persistence before dispatch.

For real PostgreSQL tests, use an explicitly disposable database (the tests apply schema, seed services and write synthetic records):

```bash
TEST_DATABASE_URL=postgresql://test_user:password@localhost/test_research python -m pytest -q
```

Local verification for this delivery: **22 tests passed; 4 PostgreSQL integration tests skipped** because no running disposable PostgreSQL instance was available. Python compilation and module imports were checked. No live bot, payment, Docker or external database smoke test was run.

Before launch, run all DB tests and exercise Telegram test-environment purchases: valid payment, amount/user mismatch, repeated updates, interrupted receipt handling, refund and refund retry, revoked/banned/expired access, owner impersonation callbacks, worker restart during delivery, and deletion after restart. Configure real terms, support, Stars prices and research. Review the security boundaries above before treating this as a production release.

## Files

- `schema.sql`, `provision-role.sql`, `init_db.py`: database provisioning.
- `bot/config.py`, `bot/crypto.py`, `bot/db.py`: settings, authenticated vault and atomic access/payment operations.
- `bot/user.py`, `bot/admin.py`, `bot/states.py`, `bot/ui.py`: menus and workflows.
- `bot/middleware.py`: private-chat, owner, ban and rate controls.
- `bot/polling.py`, `bot/workers.py`: durable receipt ingestion, delivery, deletion and broadcast jobs.
- `main.py`: application lifecycle and singleton protection.
- `tests/`: unit and opt-in integration tests.
