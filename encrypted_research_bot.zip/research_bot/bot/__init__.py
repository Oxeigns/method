"""Private research subscription bot."""
