"""Fail fast on invalid configuration, without printing secrets."""
import os
import ssl
from dataclasses import dataclass
from dotenv import load_dotenv

@dataclass(frozen=True)
class Config:
    token: str
    admin_id: int
    database_url: str
    redis_url: str
    keys: tuple[str, ...]
    payment_mode: str
    support: str
    database_ssl: object

    @classmethod
    def load(cls):
        load_dotenv()
        required = ('BOT_TOKEN', 'ADMIN_ID', 'DATABASE_URL', 'REDIS_URL', 'MASTER_ENCRYPTION_KEYS')
        if any(not os.getenv(k) for k in required):
            raise ValueError('Missing required settings; see .env.example.')
        mode = os.getenv('PAYMENT_MODE', 'stars')
        if mode not in {'stars', 'upi'}:
            raise ValueError('PAYMENT_MODE must be stars or upi.')
        if mode == 'upi' and os.getenv('ACKNOWLEDGE_UPI_PLATFORM_RESTRICTION') != 'true':
            raise ValueError('UPI mode is gated. Read the payment restriction in README.')
        admin = int(os.environ['ADMIN_ID'])
        if admin <= 0:
            raise ValueError('ADMIN_ID must be a positive Telegram user ID.')
        tls = os.getenv('DATABASE_SSL', 'require')
        if tls not in {'require', 'disable'}:
            raise ValueError('DATABASE_SSL must be require or disable (local development only).')
        return cls(os.environ['BOT_TOKEN'], admin, os.environ['DATABASE_URL'],
                   os.environ['REDIS_URL'], tuple(os.environ['MASTER_ENCRYPTION_KEYS'].split(',')),
                   mode, os.getenv('SUPPORT_USERNAME', ''),
                   ssl.create_default_context() if tls == 'require' else False)
