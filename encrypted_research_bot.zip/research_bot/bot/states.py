from aiogram.fsm.state import State, StatesGroup

class Checkout(StatesGroup):
    waiting_for_screenshot = State()

class Owner(StatesGroup):
    setting = State()
    service = State()
    vault_service = State()
    vault_text = State()
    users = State()
    broadcast = State()
    broadcast_confirm = State()
    refund = State()
