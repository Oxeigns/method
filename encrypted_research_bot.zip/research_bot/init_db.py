"""Apply the idempotent initial schema with the migration owner's DATABASE_URL."""
import asyncio
from pathlib import Path
import asyncpg
from bot.config import Config

async def main():
    cfg = Config.load()
    conn = await asyncpg.connect(cfg.database_url, ssl=cfg.database_ssl)
    try:
        await conn.execute(Path(__file__).with_name('schema.sql').read_text())
    finally:
        await conn.close()

if __name__ == '__main__':
    asyncio.run(main())
